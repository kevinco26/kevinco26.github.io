#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



#include "network.h"
#include "tiptap.h"



#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>



// Variable to keep track of the socket file descriptor
static int sock = -1;

// Convenience function to sign-extend a 9-bit two's complement number into
// something bigger.  Takes the 9-bit version and returns a value suitable for
// storing in a signed integer of any sort.
int signextend_9bit(int nine_bit)
{
	if (nine_bit & (1L << 8))
		nine_bit |= ~((1L << 9) - 1);
	return nine_bit;
}

// Do a helper UNPACK BYTES function instead of packing the bytes because we need to figure out what was the command
//  sent to the instruction (power on, move, etc)

void unPackBytes(uint32_t insn,uint32_t *op,uint32_t *mat,uint32_t *flags,int32_t *dist,uint32_t *seq)
{
    *op =(insn>>27)&0x1f; 
    *mat =(insn>>23)&0xf; 
    *dist =(insn>>14)&0xf; 
    *flags =(insn>>10)&0xf;
    *seq =(insn)&0xff; 
    
}

// Helper client function for connecting to a server
int client_operation() 
{
    
    // This function will connect the socket. It will be called when the opcode of the instruction sent to the server
    // Is to turn on the printer. We just want to set up the connection when we turn on the printer and not each time we send an instruction

    // Specify the constants and to what ip/port the socket will connect to.
    struct sockaddr_in caddr;
    char *ip = TIPTAP_IP;
    caddr.sin_family = AF_INET;
    caddr.sin_port = htons(TIPTAP_PORT);

    if ( inet_aton(ip, &caddr.sin_addr) == 0 ) {
        return( -1 );
    }

    // Creating the socket. Assigning it to the global variable named sock.

    sock = socket(PF_INET, SOCK_STREAM, 0);
    if (sock == -1)
	{
        printf( "Error on socket creation [%s]\n", strerror(errno) );
        return -1 ;
    }

    // Connecting the socket. Also, checking for errors as before.
    if ( connect(sock, (const struct sockaddr *)&caddr, sizeof(struct sockaddr)) == -1 ) 
    {
        printf( "Error on socket connect [%s]\n", strerror(errno));
        return -1 ;
	}
	
	return 0;
}

// Network interface for the TipTap 3-D printer
int tapctl(uint32_t insn, void *buf)
{

    /* ========================================= DATA DICTIONARY ===============================================*/
    
    uint32_t flags, op, mat,seq;                    // Variables to hold the specific values of the instruction once "unpacked"
    int32_t dist;                                   // Since distance can be signed, we declared it as int32_t
    uint16_t finalDistance;                         // Sign extended distance.
    
    int clientOperation;                            // Start the connection, variable to hold the returned value from the call to client_operation()
    
    struct requestMessage;                          // Struct that will represent the request message

    void *temp;                                     // Temporary pointer when solving issues of copying memory and not losing the origin of the pointer.
    void *responseMessage;                          // Malloc'd array to hold the response message from the server

    uint32_t writeBytes;                            // Writing to the server
    uint32_t readBytes;                             // Reading from the server
    
    /* ========================================= DATA DICTIONARY ===============================================*/


    // Unpack the bytes from the instruction 
    unPackBytes(insn,&op,&mat,&flags,&dist,&seq);

    // Values sent to the server musst be converted to network byte order. (Host to network long. Long because it is uint32_t)
    insn = htonl(insn);

    finalDistance = abs(signextend_9bit(dist));
    // Handling for when the opcode is TT_POWERON
    if(op == TT_POWERON)
    {
        
        // Start the connection, check for errors
        clientOperation = client_operation();
        if(clientOperation !=0)
            return -1;

        // Compose the request message. Instruction, 0 bytes in the data buffer because there is no data buffer sent
        struct requestMessage{

        uint32_t insn; 
        uint16_t size; 

        };

        struct  requestMessage messageTosend;
       
        messageTosend.insn = insn;
        messageTosend.size = htons(0);


        // Malloc the response message
        responseMessage = malloc(8*sizeof(void));

        temp = responseMessage;
       
        //Writing to the socket
        if(write( sock, &messageTosend,6) != 6) 
        {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
        }
        /// Reading the response message
        if(read( sock, responseMessage, 8) != 8) 
         {
            printf("Error writing network data [%s]\n", strerror(errno) );
            return -1;
         }

          // Check return value which is at offset 0
         if(ntohs(*((uint16_t*)responseMessage)) != 0)
            return -1;
        
        // Now, when we turn on the printer, two values are returned, and so we must set the buffer from tapctl(buf) to those values returned
        // We will use memcpy since we are copying information from array to array(pointer to pointer)

        responseMessage+=4;
        memcpy(buf,responseMessage,4);
        
        responseMessage = temp;

        // Free the mallocd response message.
        free(responseMessage);

    }
    // Checking now if the flag is Probe
    else if(flags == TTFLAG_PROBE)
    {

        // Construct the request message, again, 0 bytes to send as the size of the data buffer because we are not sending any data buffer
        struct requestMessage{
            
            uint32_t insn; 
            uint16_t size; 
       
        };

        struct  requestMessage messageTosend;
       
        messageTosend.insn = insn;
        messageTosend.size = htons(0);


        responseMessage = malloc((6)*sizeof(void));
        
        temp = responseMessage;

        writeBytes = write(sock,&messageTosend,6);

        if(writeBytes != 6) 
        {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
        }

      
        readBytes = read(sock,responseMessage,6);

        if((int)readBytes!= 6) 
        {
            printf( "Error Reading network data [%s]\n", strerror(errno) );
            return -1;
        }
        
        // Check error value

        if(ntohs(*((uint16_t*)responseMessage)) != 0)
            return -1;
  
        // As with Powering on, when we probe we get the depth. We must store that into the buf parameter of tapctl
        responseMessage+=4;  

        memcpy(buf,responseMessage,2);
  
        responseMessage = temp;
    
        // Deallocate the mallocd array
        free(responseMessage);
       
    }
    // Handling for extruding
    else if(flags == TTFLAG_EXTRUDE)
    {
        
       // Construct the requestMessage, this time we will send a data buffer which contains the materials. 
       // The size will be the distance that we want to print
       
       struct requestMessage{
        
        uint32_t insn; 
        uint16_t size; 
        uint8_t materialsBuffer[finalDistance];
       
       };

       struct  requestMessage messageTosend;
       
        messageTosend.insn = insn;
        messageTosend.size = htons(finalDistance);
        // Copy the contents of the buffer passed to tapctl to the request message to be sent to the server
        memcpy(messageTosend.materialsBuffer,buf,finalDistance);

        responseMessage = malloc(4*sizeof(void));

        writeBytes = write(sock,&messageTosend,6+finalDistance);


        if((int)writeBytes != 6+finalDistance) 
        {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
        }

        if(read( sock, responseMessage, 4) != 4) 
        {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
        }

        // Check for error
        if(ntohs(*((uint16_t*)responseMessage)) != 0)
            return -1;
    
        // Deallocate the response message  
        free(responseMessage);

    }
    // If the opcode is Power Off or any of the move commands, the request message is the same
    else if(op == TT_POWEROFF || op == TT_MOVEX || op == TT_MOVEY || op == TT_MOVEZ )
    {

        // Request Message. No buffer sent.
        struct requestMessage{
        
        uint32_t insn; 
        uint16_t size; 
       
       };

        struct  requestMessage messageTosend;
       
        messageTosend.insn = insn;
        messageTosend.size = htons(0);

        responseMessage = malloc(6*sizeof(void));

         if(write( sock, &messageTosend,6) != 6) 
         {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
         }
          
        if(read( sock, responseMessage, 4) != 4) 
        {
            printf( "Error writing network data [%s]\n", strerror(errno) );
            return -1;
        }

        // Check return value.
        if(ntohs(*((uint16_t*)responseMessage)) != 0)
            return -1;


        free(responseMessage);
    
        // Close the connection
        if(op == TT_POWEROFF)
        {
            // Close the socket if we turned the printer off.
            // For good programming practice, set the socket variable to -1.
            close(sock);
            sock = -1;
        }
    }
    
    // If no errors were found, return 0 signifying success
	return 0;
}
