int run_server(int, char **);

int main(int argc, char **argv)
{
	return run_server(argc, argv);
}
