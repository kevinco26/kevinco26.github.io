
 // Pinhas Kevin Cohen
 // Cmpsc311 Assignment 3. 3d Printer Driver.
 // March 10, 2015

/*
 * Source file for the TipTap driver.  This is where you will implement the
 * user-facing API (tiptap_*) for the TipTap, using the tapctl() hardware
 * interface to communicate with the device.
 */


#include <stdint.h>
#include <stdio.h>
#include "tiptap.h"
#include "driver.h"
#include <stdlib.h>

// Listing all the helper functions that we are going to use in the entire program.


// Since we need to pack the fields in a 32 bit integer, it is better to pack them,
//  return the 32 bit int which we can use as an argument for the tapctl function
uint32_t helperPackBytes(uint32_t seq, uint32_t flags, int32_t dist, uint32_t mat, uint32_t op)
{
	
	uint32_t returningValue, tempOp, tempMat, tempFlags, tempSeq;
	int32_t tempDist;

	// We are masking to the required bits as specified in the instruction and then we are returning all of the bits "packed" together
	
	tempSeq   =  seq&0x3ff; 
	tempFlags  =  (flags&0xf)<<10; 
	tempDist  =  (dist&0x1fff)<<14; 
	tempMat   =  (mat&0xf)<<23; 
	tempOp    =  (op&0x1f)<<27; 
	
	// After correctly shifting, put them together into a single 32 bit integer.
	returningValue = tempSeq|tempFlags|tempDist|tempMat|tempOp;
	
	return returningValue;
	
}

// This function will return true if all the materials in one row are the same or 0.
// {0,1,1,0,1} and  {1,1,1,1} will both return true but {1,1,1,0,2} will return false
// The purpose of this function is to determine if we can call ONE time tapctl with the TTFLAG_EXTRUDE flag passed
// If all the materials in a row are the same, or between one material and 0 then we call tapctl only ONCE later on.
int helperMaterial(uint8_t materials[],uint16_t size)
{
	int value;
	int count;

	// for the number of 0s
	count = 0;
	value = 0;
	for(int i = 0; i < size; i++)
	{
		// First time it encounters a non zero value. Increment count.

		if(materials[i] != value && materials[i] !=0){
			value = materials[i];
			count++;
		}

	}
	//If count is greater than 1, then it encountered 2 different values therefore return false(1).
	
	if(count>1)
		return 1;
	//Else, return 0 which means all materials are the same or are one material and 0

	return 0;
}

// This function will store the current material that we want to extrude.
int determineMaterial(uint8_t materials[],uint16_t size){


	int returnedMaterial = materials[0];

	// Search in the for loop for a material that is not 0 because we can't extrude with the material field to 0.
	for(int i = 0; i< size; i ++)
	{
		if(materials[i]!=0)
			returnedMaterial = materials[i];
	}


	return returnedMaterial;
}

// Power on the printer.
int tiptap_init(struct tiptap *tt)
{

	/*=================================================== DATA DICTIONARY =========================================================*/
	
	uint32_t firstInstruction;			// Variable to hold the 32 bit int instruction of the packed instruction for turned on.
	uint32_t secondInstruction;			// Variable to hold the 32 bit int instruction of the packed instructions for the flag probe.
	
	int checkError;						// SecondInstructionError(Output of the tapctl function)
	int checkErrorSecondInstruction;	// SecondInstructionError(Output of the tapctl function)
	
	uint16_t getxyDim[2];		 		// Buffer to read the x and y dimensions.
	uint16_t distanceData[1];			// Buffer to read the depth of the nozzle

	/*=================================================== DATA DICTIONARY =========================================================*/
	
	
	tt->sequenceNumber = 0;				// Setting the sequence number to 0

	firstInstruction = helperPackBytes(tt->sequenceNumber,0,0,0,TT_POWERON);    
	tt->sequenceNumber++;

	checkError = tapctl(firstInstruction,getxyDim);
	tt_error(checkError);								// Success if the value returned from tapctl = 0. Failure otherwise.

	tt->bedWidth = getxyDim[0];
	tt->bedHeight = getxyDim[1];
	
	// Finding the depth of the nozzle.
	secondInstruction = helperPackBytes(tt->sequenceNumber,TTFLAG_PROBE,0,0,TT_MOVEX);
	tt->sequenceNumber++;
	
	checkErrorSecondInstruction = tapctl(secondInstruction,distanceData);
	tt_error(checkErrorSecondInstruction);									// Success if the value returned from tapctl = 0. Failure otherwise.
	

	tt->xPos = 0;			 	 			// Setting the x coordinate of the print nozzle.
	tt->yPos = 0;			 	 			// Setting they y coordinate of the print nozzle.
	tt->zPos = distanceData[0];	 	 		// Setting the z coordinate of the print nozzle.
	tt->bedDepth = distanceData[0]; 	 	// Setting the bedDepth of the print bed. 
	
	return 0;			        			// Return 0 which means success from the function
}

// Turn the printer off
void tiptap_destroy(struct tiptap *tt)
{
	
	
	int checkError;			// Check error for power off instruction		
	uint32_t packedOff;		// 32bit instructions for power off

	packedOff = helperPackBytes(tt->sequenceNumber,0,0,0,TT_POWEROFF);
	
	checkError = tapctl(packedOff,NULL);
	tt_error(checkError);
	tt->sequenceNumber++;
	
}

// Move to a specified location
int tiptap_moveto(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t z)
{

	/*=================================================== DATA DICTIONARY =========================================================*/
	uint32_t packedMoveX;	// 32 bit instruction to send with MOVEX opcode
	uint32_t packedMoveY;	// 32  bit instruction to send with MOVEY opcode
	uint32_t packedMoveZ;	// 32 bit instruction to send with MOVEZ opcode

	int moveX;				// To catch an error if any when the MOVEX command is executed
	int moveY;				// To catch an error if any when the MOVEY command is executed
	int moveZ;				// To catch an error if any when the MOVEZ command is executed
	
	
	int32_t twosCompleX,twosCompleY,twosCompleZ;	// Variables to hold the two's complement of the difference between the current position and the target location desired

	
	int32_t differenceX,differenceY,differenceZ;	// Variables to hold the difference of the current position and the target position

	
	int countX,countY,countZ;						// Keeping track of the number of times we need to move(this is for big numbers)
	
	int sum;										// Keep track of the "sum" which is the number of times we are going to add 255 or substract 256 to the twos complement to get the final distance that we need to move(this is in case we must move several times in the same command)
/*=================================================== DATA DICTIONARY =========================================================*/
	
	// Setting the variables.
	sum = 0;
	countX =1;
	countY = 1;
	countZ = 1;

	// If x or y are greater than the dimensions of the print bed then return 1 which means error. Also if z is higher than the bed depth, return 1 which means error.
	if(x >= tt->bedWidth || y >= tt->bedHeight || z > tt->bedDepth )
		return 1;	
	
	// Setting the difference to be the actual position minus the target position. This can either be negative or positive
	differenceX = tt->xPos - x;
	differenceY = tt->yPos - y;
	differenceZ = tt->zPos - z;
	
	// Getting the two's complement and masking it with 9 bits because of the number of bits in the distance field for the instruction.
	twosCompleX = (~(differenceX) +1)&0x1ff;
	twosCompleY = (~(differenceY) +1)&0x1ff;
	twosCompleZ = (~(differenceZ) +1)&0x1ff;
	
	// While loop to account for extra moving in the x direction. If the move steps are greater than 256 or less than -255 we need to do more moves to get to the desired one.
	//  This happens because the range is [-256,255] because of the number of bits passed to the distance field.
	//  Note that the twos complement of 256 will be -256 for example and the twos complement of 255 will be -255.
	while(differenceX <-255 || differenceX >256)
	{
		// Account for extra moves in the x direction if the required moving steps are less than -255.
		if(differenceX < -255)
		{
			differenceX+=255;
			twosCompleX = (~(-255) +1)&0x1ff;
			
		}
		// Account for extra moves in the x direction if the required moving steps are greater than 256.
		else if(differenceX>256)
		{
			differenceX-=256;
			twosCompleX = (~(256) +1)&0x1ff;
		}
		// Move 255 forward or -256 backwards. Depending on the direction desired.
		packedMoveX = helperPackBytes(tt->sequenceNumber,0,twosCompleX,0,TT_MOVEX);
		moveX = tapctl(packedMoveX,NULL); 
		if(moveX!=0){
			return 1;
		}
		tt->sequenceNumber++;
		//tt_error(moveX);
		
		// Keep moving 255 forward or -256 backwards until we are in the range of (-256,255) and we don't need to make extra moves.
		// Keep track of the number of times we moved extra so that we know later on how many bits we need to add to move the last final difference.
		countX++;

	}
	// Samme comments apply in the following loops but they are in the y direction and z direction respectively.
	while(differenceY <-255 || differenceY >256)
	{
		if(differenceY < -255)
		{
			differenceY+=255;
			twosCompleY = (~(-255) +1)&0x1ff;
			
		}
		else if(differenceY>256)
		{
			differenceY-=256;
			twosCompleY = (~(256) +1)&0x1ff;
		}
		packedMoveY = helperPackBytes(tt->sequenceNumber,0,twosCompleY,0,TT_MOVEY);
		moveY = tapctl(packedMoveY,NULL); 
		if(moveY!=0){
			return 1;
		}
		tt->sequenceNumber++;
		//tt_error(moveX);
		
		countY++;
	}
	

	while(differenceZ <-255 || differenceZ >256)
	{
		if(differenceZ < -255)
		{
			differenceZ+=255;
			twosCompleZ = (~(-255) +1)&0x1ff;
			
		}
		else if(differenceZ>256)
		{
			differenceZ-=256;
			twosCompleZ = (~(256) +1)&0x1ff;
		}
		packedMoveZ = helperPackBytes(tt->sequenceNumber,0,twosCompleZ,0,TT_MOVEZ);
		moveZ = tapctl(packedMoveZ,NULL); 
		if(moveZ!=0){
			return 1;
		}
		tt->sequenceNumber++;
		//tt_error(moveX);
		
		countZ++;
	}

	// If we did those extra steps( here is where the countX,countY and countZ variables come in play), then update the twos complement to be the last final difference that we need to move.
	// For exampple. if we needed to move 555. Then we moved 255 two times to get to 510. But then 510 - 555 is -45 and so we move +45(because of the twos complement).
	
	if(countX>1){
		differenceX = tt->xPos - x;
		for(int i =0; i < countX-1;i++)
		{

			if(differenceX < 0)
				sum+=255;
			else
				sum-=256;
		}
		
		twosCompleX = (~(differenceX + sum) +1)&0x1ff;
		sum = 0;
	}

	if(countY>1){
		differenceY = tt->yPos - y;
		for(int i =0; i < countY-1;i++)
		{
			if(differenceY < 0)
				sum+=255;
			else
				sum-=256;
		}
		twosCompleY = (~(differenceY + sum) +1)&0x1ff;
		sum = 0;
	}
	
	if(countZ>1){
		differenceZ = tt->zPos - z;
		for(int i =0; i < countZ-1;i++)
		{
			if(differenceZ < 0)
				sum+=255;
			else
				sum-=256;
		}

		twosCompleZ = (~(differenceZ + sum) +1)&0x1ff;
		sum = 0;
	}
					
		// Moving on with regular moves after the extended moves(if needed i.e the distance to move was too big) occured
		if(twosCompleX!=0)
		{
			packedMoveX = helperPackBytes(tt->sequenceNumber,0,twosCompleX,0,TT_MOVEX);
			moveX = tapctl(packedMoveX,NULL); 
			if(moveX!=0){
				return 1;
			}
			tt->sequenceNumber++;
			//tt_error(moveX);
			
		}
		if(twosCompleY!=0)
		{
			packedMoveY = helperPackBytes(tt->sequenceNumber,0,twosCompleY,0,TT_MOVEY);
			moveY = tapctl(packedMoveY,NULL);
			//tt_error(moveY);
			if(moveY!=0)
				return 1;
			tt->sequenceNumber++;
			
		}
		if(twosCompleZ!=0)
		{
			packedMoveZ = helperPackBytes(tt->sequenceNumber,0,twosCompleZ,0,TT_MOVEZ);
			moveZ = tapctl(packedMoveZ,NULL);
			//tt_error(moveZ);
			if(moveZ!=0)
				return 1;
			tt->sequenceNumber++;
			
		}
	
	//Setting the  x,y,z coordinates to the new ones which are the ones passed to the function(the coordinates that we wanted to reach when we moved)
	tt->xPos = x;
	tt->yPos = y;
	tt->zPos = z;
		
	return 0;
}

/// Get the position at a certain locationn
void tiptap_getpos(struct tiptap *tt, uint16_t *x, uint16_t *y, uint16_t *z)
{
	// Storing the value of the current coordinate to the output parameters by using the reference operator(*)
	*x = tt->xPos;
	*y = tt->yPos;
	*z = tt->zPos;
}

// print for an entire layer(rectangle specified by a certain width and height)
int tiptap_printlayer(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t *materials)
{


	// Checking to see if the rectangle falls outside the printing bed
	// And check if the current z positon allows for printing
	// We also need to check for the probe reading to see if there is exactly one unit beneath the nozzle for the printing to occur.
	if(x + w > tt->bedWidth || y+h > tt->bedHeight || tt->zPos > tt->bedDepth)
		return 1;


	/*================================================ DATA DICTIONARY ==================================================*/

	int moveToPosition;							// Variable used to move to a certain location by calling the tiptap_moveto function.

	uint32_t instructionPerRow;					// Instrucion sent to tapCtl.
	int checkError;								// To check for error once passed the above instruction.

	uint16_t startingY;							// Initial position to start.

	uint8_t data[h][w];							// We will store the materials passed from the materials parameter into this double dimensional array.
	uint8_t tempBuffer[w];						// Temporary buffer to store the rows.

	int rows;									// To keep track of the rows in the data array and store the next row in tempBuffer after each iteration of the while loop.
	int r;										// To keep track of the rwos when we are handling the case of one column only.
	int helperMat;								// calls to the helper functions. This will store whether all the values of the temporary buffer are of one material or one material and "0" or different materials
	int determineMat;							// This will contain the current material that we want to extrude

	int tempWidth;								// Temporary width when the distance require to print is greater than 255
	int tempHeight;								// Temporary height when the distance require to print is greater than 255

	int value;									// Hold the current value of the data array if there are different materials in the array.
	int differentMaterial;						// To check if all the materials are the same


	uint32_t instructionProbe;					// Instruction to be sent for probing
	int checkErrorProbe;						// As always check if the return from tapctl returns failure
	int move;									// To store the value when called the tiptap_moveto function.
	
	uint16_t startY;							// The starting y coordinate at which we will start to check the probing			
	int row;									// This will start at 0 and increment each time we go in the while loop for checking the probe
	const uint8_t *tempMat = materials;			// Temporary pointer that points at whatever the materials parameter passed is pointing.
	uint8_t tempData[h][w];						// Store all the values of the materials paraemeter in this temporary double dimensional array to check the probing.

	/*================================================ DATA DICTIONARY ==================================================*/

	startY = y;
	move = tiptap_moveto(tt,x,y,tt->zPos);		// Move at the desired starting coordinates

	if(move!=0)
		return 1;


	
	// fill the elements of the temporary arry that will contain the materials.
	for(int i = 0; i<h ; i++)
	{	
		for(int j = 0; j<w;j++)
		{
			tempData[i][j] = *tempMat;
			tempMat = tempMat +1;

		}	
	} 
	
	/*
	// Increment row after each iteration of the while loop but start at 0.
	row = 0;
	// If we are not printing over the boundaries and we can move a distance of up to 255 then check 
	// If we are allowed to print(check if there is material below or if there is not.)
	if(x+w != tt->bedWidth && w<=255 && h<=255)
	{
		// Temporary buffer to be sent to tapCtl. This buffer whill contain the probe readings for an entire row.
		uint16_t dataProbe[w];
		while(startY< y+h)
		{
			instructionProbe = helperPackBytes(tt->sequenceNumber,TTFLAG_PROBE,w,0,TT_MOVEX);
			checkErrorProbe = tapctl(instructionProbe,dataProbe);
			
			if(checkErrorProbe!=0)
				return 1;
			

			tt->sequenceNumber++;
			tt->xPos = w+x;
			// This is where the checking comes in play.
			//  We traverse the whole buffer returned by the tapctl which will have the probe readings of an entire row.
			//  If the reading is not 1: it could be 0 which means there is material underneath, then return failure. Or oit could be greater than 1
			//  In this case it means that there is more than one unit of space beneath the nozzle.
			//  This is acceptable as long as the desired printing material is 0(don't print) But if the desired material is not 0 and we have a space of more than one unit beneath the nozzle,
			//  then we need to return 1(failure) because the material would fall all the way down and not print at the given layer(the materials do not stay in the air, they need to have something beneat them)

			//for(int k = 0; k<w;k++) 
			//	if(dataProbe[k] != 1 && tempData[row][k] != 0 )
			//		return 1;
				
			row++;
			startY++;
			move = tiptap_moveto(tt,x,startY,tt->zPos);

		}
	}
	// Else we are printing on the boundaries. Traverse the same way but do not take into consideration the last coordinate
	else if(x+w == tt->bedWidth && w<=255 && h<=255)
	{

		uint16_t dataProbe[w-1];
		while(startY< y+h)
		{
			instructionProbe = helperPackBytes(tt->sequenceNumber,TTFLAG_PROBE,w-1,0,TT_MOVEX);
			checkErrorProbe = tapctl(instructionProbe,dataProbe);
			if(checkErrorProbe!=0)
				return 1;
			tt->sequenceNumber++;
			tt->xPos = w+x-1;
			//for(int k = 0; k<w-1;k++)
			//	if(dataProbe[k] != 1 && tempData[row][k] != 0 )
				//	return 1;
				

			startY++;
			row++;
			move = tiptap_moveto(tt,x,startY,tt->zPos);
		}
	}
	*/
	/* ==============================	FINISHED CHECKING FOR ANY FAILURE	================================ */
	
	// If we are allowed to print. Start printing process.
	
	startingY = y;
	// move the nozzle to the top height of the rectangle so we can go from top to bottom (in the y direction, do not confuse with z Position which we start at the ground.)
	moveToPosition = tiptap_moveto(tt,x,startingY,tt->zPos);
	// Check for error if we can't move to the certain position.
	if (moveToPosition !=0)
		return 1;
	
	// For loop to fill the elements of the data array from the materials array passed to the function
	for(int i = 0; i<h ; i++)
	{	
		for(int j = 0; j<w;j++)
		{
			data[i][j] = *materials;
			//fprintf(stderr, "%d ",(int)data[i][j]);
			materials = materials +1;

		}
		//fprintf(stderr, " \n");
		
	} 

	// Start at 0, increment to go to the last y value of the materials array passed to the function.	
	// Fill the elements of the temporary buffer(which will contain one row at a time.)
	rows = 0;
	for(int i = 0; i < w; i++){
		tempBuffer[i] = data[rows][i];	
	}

	// While loop to go through each row of all the rows of the materials array.
	// The general printing algorithm idea is that we print every column, go down a row and repeat.
	differentMaterial=0;
	value = data[0][0];

				//Nested for loops to traverse through the whole data array(double dimensional array) and check if all the materials are the same or zero.
	for(int r = 1; r< h; r++)
	{
		for(int c = 0; c<w; c++)
		{
			if(value != data[r][c] && data[r][c] != 0)
			{
				value =data[r][c];
				differentMaterial++;
			}
		}
	}

	// To handle when we only have one column. To be more efficient, print vertically.
	// Obtain all the rows.
	r = 0;	
	// If we only have one column and not all the materials are the same
	if(w ==1 && differentMaterial>1)
	{
		// Keep looping through all the rows untl we reach the end. The difference is that we are going to print vertically to avoid moving through the next rows. 
		// With this we eliminate all unnecessary moving steps.
		while(startingY< h+y)
		{
			determineMat = data[r][0];
			if(determineMat!=0)
			{
					instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,1,determineMat,TT_MOVEY);
					checkError = tapctl(instructionPerRow,tempBuffer);
					tt->yPos++;
					if(checkError!=0)
						return 1;
					tt->sequenceNumber++;
					startingY++;
			}
			else
			{
				tiptap_moveto(tt,x,startingY+1,tt->zPos);
				startingY++;
			}
			r++;
		}
		return  0;
	}

	while(startingY < h+y)
	{	
		helperMat = helperMaterial(tempBuffer,w);			// Helper function to determine if we have only one material in the specified row(or one material and 0)	
		
		if(helperMat != 0)									// If we have more than one material, we will need to print one material at a time and move one x position.
		{	
		// Move only 1 and extrude that material at that position using a for loop to go through each column.
		// This is slower than if all the materials are the same because if all the materials are the same we just issue one command for the entire row and we don't need a for loop.		
			for(int i = 0; i < w; i++){
					// Error checking to see if the material is 0. If it is, move to the next x position WITHOUT extruding
				if(tempBuffer[i] == 0)
				{
					moveToPosition = tiptap_moveto(tt,tt->xPos+1,startingY,tt->zPos);

						// Error checking: if the material is 0 AND the first material is 0 then we set the first material to 1
						// so that next time if we go through the loop and the material is not 0 we will actually print the desired material.
					if(tempBuffer[0] == 0)
						tempBuffer[0] = 1;
				}
					// If it's not zero, continue and print one element at a time
				else
				{
						determineMat = tempBuffer[i];		// Use helper function to determine the material we are going to extrude.
						
						if(tt->xPos == tt->bedWidth-1)		// Error checking if we are printing on the boundaries. If so, extrude the given material but DO NOT move.
						{	
							instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,0,determineMat,TT_MOVEX);
							checkError = tapctl(instructionPerRow,tempBuffer);
							
						}
						else 								// Else, print the desired material and advance one in the x position.
						{	

							instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,1,determineMat,TT_MOVEX);
							checkError = tapctl(instructionPerRow,tempBuffer);
							tt->xPos++;						// Update the x position by 1 because we moved one with the above command
						}	
						if(checkError!=0)					// Check if the call to tapCtl returns an error.
							return 1;

						tt->sequenceNumber++;				// Update the sequence number.
						
					}
				}
				// Error checking for boundary case. If we are printing on the boundary, then the x position should be one less than the boundary.
				if(x+w == tt->bedWidth)
					tt->xPos = tt->bedWidth-1;
		}
		// Else, if all the materials in one row are the same or one material and 0.
		else
		{
			// Print the entire row for ONE material because that row is composed by just 1 material
		
			tempWidth = w;
			tempHeight = h;

			determineMat = determineMaterial(tempBuffer,w);
			
			// If the width is greater than 255 then the required moving steps should be divided into smaller pieces.
			if(w>255)
			{
					// Account for when the width is greater than 255. Same algorith than moveTo. print and move 255 until the temporary width is less than or equal to 255.
					// When this happens, print and move the distance of temporaryWidth.
					while(tempWidth>255)
					{
						// Prit and move 255, check for error as usual and update the tempwidth to be 255 less than the current tempWidth.
						instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,255,determineMat,TT_MOVEX);
						checkError = tapctl(instructionPerRow,tempBuffer);
						if(checkError!=0)
							return 1;
						tt->sequenceNumber++;
						tempWidth = tempWidth-255;
					}
					instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,tempWidth,determineMat,TT_MOVEX);
					checkError = tapctl(instructionPerRow,tempBuffer);
					if(checkError!=0)
						return 1;
					tt->sequenceNumber++;
			}
			// Else if the width is less than or equal to 255, print the row with the given distance as width.
			else
			{

				determineMat = determineMaterial(tempBuffer,w);		
				
				// Determine now if ALL the materials(not only in one row) of the materials array are the same.
				// If they are the same, then handle that case to be more efficient.
				differentMaterial=0;
				value = data[0][0];

				//Nested for loops to traverse through the whole data array(double dimensional array) and check if all the materials are the same or zero.
				for(int r = 1; r< h; r++)
				{
					for(int c = 0; c<w; c++)
					{
						if(value != data[r][c] && data[r][c] != 0)
						{
							value =data[r][c];
							differentMaterial++;
						}
					}
				}
				// If all the materials are the same or zero AND the height is greater than 255 then to be more efficient print in columns instead of rows.			
				// Also, we are going to return inside this if because we are considering the case that the width is also 1. After printing the column, we are done. 
				if(h>255 && w==1 && differentMaterial <=1)
				{
					// Same algorithm as if the width is greater than 255 but now with height. 
					// Since we are printing by columns then print vertically by extruding and issuing the MOVEY command instead of the MOVEX command.
					tempHeight = 255;	
					while(tempHeight>255)
					{
						instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,255,determineMat,TT_MOVEY);
						checkError = tapctl(instructionPerRow,tempBuffer);
						if(checkError!=0)
							return 1;
						tt->sequenceNumber++;
						tempHeight = tempHeight-255;
					}

					instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,tempHeight,determineMat,TT_MOVEY);
					checkError = tapctl(instructionPerRow,tempBuffer);
					if(checkError!=0)
						return 1;
					tt->sequenceNumber++;
					tt->yPos = h;

					if(tt->zPos+1 != tt->bedDepth)
					{
						moveToPosition = tiptap_moveto(tt,tt->xPos,tt->yPos,tt->zPos+1);
						if(moveToPosition !=0)
							return 1;
					}
					return 0;		
				}
				//Finally if neither the width nor the height are greater than 255, print the row.
				// Handle case for boundaries. Print the entire row until the boundary-1.
				
				if(x+w == tt->bedWidth){
					if(determineMat!=0)
						instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,w-1,determineMat,TT_MOVEX);	
					else
					{
						instructionPerRow = helperPackBytes(tt->sequenceNumber,0,w-1,0,TT_MOVEX);
						tt->xPos = x+w;		
					}
					// Else, print the entire row but handle case for 0.
				}
				else
				{	
					//fprintf(stderr, "Material is: %d\n",determineMat);
					// If the material to extrude is not 0, print the entire row.
					if(determineMat!=0)
						instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,w,determineMat,TT_MOVEX);
					// Else, move one x position and do not extrude.
					else
					{
						instructionPerRow = helperPackBytes(tt->sequenceNumber,0,w,0,TT_MOVEX);
						tt->xPos = w;																// Update the x position to be one more than the one before.
					}
				}

				// Check the error if the tapctl function returns a nonzero value as always checked and update the sequence number if it is successful.
				checkError = tapctl(instructionPerRow,tempBuffer);
				
				if(checkError!=0)
					return 1;
				tt->sequenceNumber++;
					
			}

			// One extra special case, if we are printing in the boundary and the last element to extrude is not 0 then print that last element.
			// Since in the above case we printed up until the boundary-1 if we were printing in the boundary, then account for that extra material not printed.
			if(x+w == tt->bedWidth && tempBuffer[w-1]!=0)
			{
				instructionPerRow = helperPackBytes(tt->sequenceNumber,TTFLAG_EXTRUDE,0,determineMat,TT_MOVEX);	
				checkError = tapctl(instructionPerRow,tempBuffer);
				if(checkError!=0)
					return 1;
				tt->sequenceNumber++;
			}
			//If printed on the boundary, final x position is one less than the boundary
			if(x+w == tt->bedWidth)
				tt->xPos = x+w-1;
			//Else, final x position is the position where we started plus the width of the specified rectangle.
			else
				tt->xPos = x+w;
		}		
		// We need the above settings of x positions because now we are going to update the heigth to be one more,
		//  and move to that height and to the original x position(where we started) specified in the function.

		startingY++;
		moveToPosition = tiptap_moveto(tt,x,startingY,tt->zPos);

		// Now fill the contents of the temporary buffer to be the next row of the data array which will contain the next row of the materials passed to the function.
		rows++;										// Next row.				
		for(int i = 0; i < w; i++)
		{
			tempBuffer[i] = data[rows][i];	
		}
		
		
	}
	int logLayer;
	logLayer = tt_log_layer(tt->zPos-1);
	// End of while loop.
	// If we can move to a higher z position, moveto the higher z position(z position +1)
	if(tt->zPos+1 != tt->bedDepth){
		moveToPosition = tiptap_moveto(tt,tt->xPos,tt->yPos,tt->zPos+1);
		if (moveToPosition !=0)
			return 1;
	}
	return 0;
}

/* Bonus */
int tiptap_scan(struct tiptap *tt, uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t *output)
{	

	uint32_t instructionProbe;
	int checkErrorProbe;
	uint16_t startY;
	int move;

	startY = y;
	move = tiptap_moveto(tt,x,y,tt->zPos);		// Move at the desired starting coordinates
	if(move!=0)
		return 1;
	
	if(x+w != tt->bedWidth && w<=255 && h<=255)
	{
		// Temporary buffer to be sent to tapCtl. This buffer whill contain the probe readings for an entire row.
		uint16_t dataProbe[w];
		while(startY< y+h)
		{
			instructionProbe = helperPackBytes(tt->sequenceNumber,TTFLAG_PROBE,w,0,TT_MOVEX);
			checkErrorProbe = tapctl(instructionProbe,dataProbe);
			if(checkErrorProbe!=0)
				return 1;
			tt->sequenceNumber++;
			tt->xPos = w+x;
			
			// Traverse through the whole buffer returned when the probe command is issued.
			for(int k = 0; k<w;k++) 
			{		
				// if the reading of the data probe minus the current height is 0(then the reading of the data probe is the full bed depth)
				// then the height is 0(no material)
				if(dataProbe[k] - tt->zPos == 0)
					*output = 0;
				// Else then the height will be the current z position - 1 - the current probe reading. We do the -1 because
				//	the way the probe reads if there is material is one unit less. i.e if we are at z position 3,
				//	and there is material at z position 2 then the reading will be 0. to account for this we say that the height is the current z position,
				//  which is 3 minus the probe reading(0) minus 1. Which will equal to a height of 2.
				else
					*output = tt->zPos-1- dataProbe[k];
				
			}
			
			startY++;
			move = tiptap_moveto(tt,x,startY,tt->zPos);
			output++;
		}
	}
	// Else we are printing on the boundaries. Traverse the same way but do not take into consideration the last coordinate
	else if(x+w == tt->bedWidth && w<=255 && h<=255)
	{

		uint16_t dataProbe[w-1];
		while(startY< y+h)
		{
			instructionProbe = helperPackBytes(tt->sequenceNumber,TTFLAG_PROBE,w-1,0,TT_MOVEX);
			checkErrorProbe = tapctl(instructionProbe,dataProbe);
			if(checkErrorProbe!=0)
				return 1;
			tt->sequenceNumber++;
			tt->xPos = w+x-1;
			for(int k = 0; k<w;k++) 
			{		
				// if the reading of the data probe minus the current height is 0(then the reading of the data probe is the full bed depth)
				// then the height is 0(no material)
				if(dataProbe[k] - tt->zPos == 0)
					*output = 0;
				else
					*output = tt->zPos-1-dataProbe[k];
			}
			startY++;
			move = tiptap_moveto(tt,x,startY,tt->zPos);
			output++;
		}
	}

	return 0;
}

